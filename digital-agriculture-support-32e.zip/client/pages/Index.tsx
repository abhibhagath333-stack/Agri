import { useState } from "react";
import { Header } from "@/components/Header";
import {
  Sprout,
  Zap,
  TrendingUp,
  Users,
  Cloud,
  BarChart3,
  Smartphone,
  Heart,
  Upload,
  Image as ImageIcon,
  FileText,
  Download,
  MapPin,
  Mail,
  Phone,
  Github,
  Linkedin,
} from "lucide-react";

// Technology icons mapping
const TechIcon = ({ name }: { name: string }) => {
  const icons: Record<string, React.ReactNode> = {
    html: "📄",
    css: "🎨",
    javascript: "⚡",
    python: "🐍",
    csharp: "C#",
    aspnet: "🔷",
    flask: "⚗️",
    mysql: "🗄️",
    ml: "🤖",
    weather: "🌤️",
    apmc: "📊",
  };
  return <span className="text-3xl">{icons[name.toLowerCase()] || name}</span>;
};

export default function Index() {
  const [uploadedImages, setUploadedImages] = useState<string[]>([]);
  const [uploadedFile, setUploadedFile] = useState<File | null>(null);
  const [uploadedAudio, setUploadedAudio] = useState<File | null>(null);
  const [uploadedVideo, setUploadedVideo] = useState<File | null>(null);

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      Array.from(e.target.files).forEach((file) => {
        const reader = new FileReader();
        reader.onload = (event) => {
          const result = event.target?.result;
          if (typeof result === "string") {
            setUploadedImages([...uploadedImages, result]);
          }
        };
        reader.readAsDataURL(file);
      });
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      setUploadedFile(e.target.files[0]);
    }
  };

  const handleAudioUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      setUploadedAudio(e.target.files[0]);
    }
  };

  const handleVideoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      setUploadedVideo(e.target.files[0]);
    }
  };

  const teamMembers = [
    { name: "Nithin P B", id: "U01BE23SOO72", role: "Team Lead" },
    { name: "Mahendra M V", id: "U01BE23SOO66", role: "Backend Developer" },
    { name: "Sachidanada C S", id: "U01BE23SOO71", role: "Frontend Developer" },
    { name: "Abhisheka H M", id: "U01BE23SO128", role: "ML Engineer" },
  ];

  const technologies = [
    { name: "HTML", category: "Frontend" },
    { name: "CSS", category: "Frontend" },
    { name: "JavaScript", category: "Frontend" },
    { name: "Python", category: "Backend" },
    { name: "C#", category: "Backend" },
    { name: "ASP.NET", category: "Backend" },
    { name: "Flask", category: "Backend" },
    { name: "MySQL", category: "Database" },
    { name: "Machine Learning", category: "AI" },
    { name: "Weather API", category: "Integration" },
    { name: "APMC Market API", category: "Integration" },
  ];

  const modules = [
    {
      title: "Farmer Module",
      description: "Personal dashboard, profile management, and crop tracking",
      icon: Sprout,
    },
    {
      title: "E-Commerce Module",
      description: "Buy and sell agricultural products directly",
      icon: TrendingUp,
    },
    {
      title: "Soil Classification & Crop Prediction",
      description: "ML-based analysis for optimal crop selection",
      icon: BarChart3,
    },
    {
      title: "APMC Market Rate Module",
      description: "Real-time market prices and trends",
      icon: Zap,
    },
    {
      title: "Government Yojana Module",
      description: "Access to agricultural schemes and subsidies",
      icon: Heart,
    },
    {
      title: "Vendor Module",
      description: "Product listing and inventory management",
      icon: Smartphone,
    },
    {
      title: "Admin Module",
      description: "System management and user control",
      icon: Cloud,
    },
  ];

  const advantages = [
    "Smart farming decisions based on data",
    "Increased productivity and yield",
    "Reduced losses and waste",
    "Better profit margins",
    "Digital empowerment of farmers",
  ];

  const disadvantages = [
    "No intelligent soil and crop analysis",
    "No real-time APMC price updates",
    "Scattered government scheme information",
    "No integrated e-commerce platform",
    "Limited weather data access",
    "Poor knowledge sharing community",
  ];

  return (
    <div className="min-h-screen bg-white">
      <Header />

      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-br from-primary/95 to-primary via-primary/90 px-4 py-20 sm:py-28 lg:py-36">
        <div className="mx-auto max-w-6xl">
          <div className="text-center animate-fade-in">
            <div className="mb-6 flex justify-center">
              <div className="rounded-2xl bg-white/20 p-4 backdrop-blur-sm">
                <Sprout className="h-16 w-16 text-white" />
              </div>
            </div>
            <h1 className="text-4xl font-bold text-white sm:text-5xl lg:text-6xl">
              Digital Agriculture Support System
            </h1>
            <p className="mt-4 text-xl text-white/90 sm:text-2xl">
              Smart Farming Through Digital Innovation
            </p>
            <p className="mt-6 text-lg text-white/80 max-w-2xl mx-auto">
              "Empowering Farmers Using Digital Technology & AI"
            </p>
            <div className="mt-8 flex flex-col gap-4 sm:flex-row sm:justify-center">
              <button className="rounded-lg bg-white px-8 py-3 font-semibold text-primary hover:bg-gray-50 transition-colors">
                Explore Project
              </button>
              <button className="rounded-lg border-2 border-white px-8 py-3 font-semibold text-white hover:bg-white/10 transition-colors">
                Learn More
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Abstract Section */}
      <section id="abstract" className="px-4 py-16 sm:py-20">
        <div className="mx-auto max-w-4xl">
          <h2 className="text-3xl font-bold text-center text-primary mb-12">
            Abstract
          </h2>
          <div className="bg-gradient-to-br from-gray-50 to-gray-100 rounded-2xl p-8 sm:p-12 border border-gray-200 shadow-lg">
            <p className="text-gray-700 leading-8 text-lg">
              To design and develop a{" "}
              <span className="font-bold text-primary">Digital Agriculture Support System</span> that
              integrates e-commerce, soil classification, crop prediction, APMC live market
              rate updates, government yojana information, weather reports, and community
              interaction, providing intelligent, data-driven agricultural support to farmers
              for improved productivity, profitability, and decision-making.
            </p>
          </div>
        </div>
      </section>

      {/* Introduction Section */}
      <section id="introduction" className="px-4 py-16 sm:py-20 bg-gray-50">
        <div className="mx-auto max-w-4xl">
          <h2 className="text-3xl font-bold text-center text-primary mb-12">
            Introduction
          </h2>
          <div className="space-y-6 text-gray-700 leading-8">
            <p className="text-lg">
              <span className="font-bold text-primary">Agriculture</span> is the backbone of
              our economy, providing food security and livelihoods to millions. However,
              farmers face unprecedented challenges in the modern era, including climate
              variability, market volatility, and limited access to real-time information.
            </p>
            <p className="text-lg">
              The <span className="font-bold text-primary">key challenges</span> faced by
              farmers include:
            </p>
            <ul className="space-y-3 text-lg ml-4">
              <li className="flex gap-3">
                <span className="text-primary font-bold">•</span>
                Lack of real-time market price information
              </li>
              <li className="flex gap-3">
                <span className="text-primary font-bold">•</span>
                Limited access to accurate soil analysis and crop recommendations
              </li>
              <li className="flex gap-3">
                <span className="text-primary font-bold">•</span>
                Uncertainty about government schemes and subsidies
              </li>
              <li className="flex gap-3">
                <span className="text-primary font-bold">•</span>
                Dependence on middlemen reducing profit margins
              </li>
            </ul>
            <p className="text-lg">
              Our <span className="font-bold text-primary">Digital Agriculture Support System</span> leverages
              machine learning, weather data, and real-time market information to empower
              farmers with intelligent, data-driven decision-making capabilities.
            </p>
          </div>
        </div>
      </section>

      {/* Existing System Section */}
      <section id="existing" className="px-4 py-16 sm:py-20">
        <div className="mx-auto max-w-4xl">
          <h2 className="text-3xl font-bold text-center text-primary mb-12">
            Existing System
          </h2>
          <div className="space-y-6 text-gray-700 leading-8">
            <p className="text-lg">
              The current agricultural ecosystem relies heavily on traditional methods:
            </p>
            <div className="grid md:grid-cols-2 gap-6">
              <div className="bg-blue-50 rounded-lg p-6 border border-blue-200">
                <h3 className="font-bold text-lg text-blue-900 mb-3">Traditional Farming</h3>
                <p>Manual soil testing, experience-based crop selection</p>
              </div>
              <div className="bg-blue-50 rounded-lg p-6 border border-blue-200">
                <h3 className="font-bold text-lg text-blue-900 mb-3">Middleman Dependency</h3>
                <p>Direct sales to retailers, no farmer-to-buyer interaction</p>
              </div>
              <div className="bg-blue-50 rounded-lg p-6 border border-blue-200">
                <h3 className="font-bold text-lg text-blue-900 mb-3">Offline Operations</h3>
                <p>Manual record keeping, no digital tracking</p>
              </div>
              <div className="bg-blue-50 rounded-lg p-6 border border-blue-200">
                <h3 className="font-bold text-lg text-blue-900 mb-3">Limited Information</h3>
                <p>No real-time price updates or market transparency</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Disadvantages Section */}
      <section className="px-4 py-16 sm:py-20 bg-red-50">
        <div className="mx-auto max-w-4xl">
          <h2 className="text-3xl font-bold text-center text-red-600 mb-12">
            Disadvantages of Existing System
          </h2>
          <div className="grid md:grid-cols-2 gap-4">
            {disadvantages.map((item, idx) => (
              <div
                key={idx}
                className="bg-white rounded-lg p-6 border border-red-200 shadow-sm hover:shadow-md transition-shadow"
              >
                <div className="flex gap-3">
                  <div className="text-red-500 font-bold text-xl">✕</div>
                  <p className="text-gray-700">{item}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Proposed System Section */}
      <section id="proposed" className="px-4 py-16 sm:py-20">
        <div className="mx-auto max-w-4xl">
          <h2 className="text-3xl font-bold text-center text-primary mb-12">
            Proposed System
          </h2>
          <div className="space-y-6 text-gray-700 leading-8">
            <p className="text-lg">
              Our <span className="font-bold text-primary">Proposed Digital Agriculture Support System</span> is a
              comprehensive platform designed to revolutionize farming:
            </p>
            <div className="grid md:grid-cols-2 gap-6">
              <div className="bg-green-50 rounded-lg p-6 border border-green-200">
                <h3 className="font-bold text-lg text-primary mb-3">ML-Based Analysis</h3>
                <p>Intelligent soil classification and crop prediction</p>
              </div>
              <div className="bg-green-50 rounded-lg p-6 border border-green-200">
                <h3 className="font-bold text-lg text-primary mb-3">Real-Time Market Data</h3>
                <p>Live APMC prices and market trends</p>
              </div>
              <div className="bg-green-50 rounded-lg p-6 border border-green-200">
                <h3 className="font-bold text-lg text-primary mb-3">E-Commerce Platform</h3>
                <p>Direct farmer-to-buyer transactions</p>
              </div>
              <div className="bg-green-50 rounded-lg p-6 border border-green-200">
                <h3 className="font-bold text-lg text-primary mb-3">Government Integration</h3>
                <p>Access to yojana and subsidy information</p>
              </div>
              <div className="bg-green-50 rounded-lg p-6 border border-green-200">
                <h3 className="font-bold text-lg text-primary mb-3">Weather Intelligence</h3>
                <p>Real-time weather updates and alerts</p>
              </div>
              <div className="bg-green-50 rounded-lg p-6 border border-green-200">
                <h3 className="font-bold text-lg text-primary mb-3">Community Forum</h3>
                <p>Knowledge sharing and farmer community</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Advantages Section */}
      <section className="px-4 py-16 sm:py-20 bg-green-50">
        <div className="mx-auto max-w-4xl">
          <h2 className="text-3xl font-bold text-center text-primary mb-12">
            Advantages of Proposed System
          </h2>
          <div className="grid md:grid-cols-2 gap-4">
            {advantages.map((item, idx) => (
              <div
                key={idx}
                className="bg-white rounded-lg p-6 border border-green-200 shadow-sm hover:shadow-md transition-shadow"
              >
                <div className="flex gap-3">
                  <div className="text-primary font-bold text-xl">✓</div>
                  <p className="text-gray-700">{item}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Modules Section */}
      <section id="modules" className="px-4 py-16 sm:py-20">
        <div className="mx-auto max-w-6xl">
          <h2 className="text-3xl font-bold text-center text-primary mb-12">
            System Modules
          </h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {modules.map((module, idx) => {
              const Icon = module.icon;
              return (
                <div
                  key={idx}
                  className="group rounded-xl bg-white p-8 border border-gray-200 shadow-md hover:shadow-xl hover:border-primary transition-all"
                >
                  <div className="mb-4 inline-block rounded-lg bg-primary/10 p-3 group-hover:bg-primary transition-colors">
                    <Icon className="h-8 w-8 text-primary group-hover:text-white" />
                  </div>
                  <h3 className="text-xl font-bold text-gray-900 mb-2">
                    {module.title}
                  </h3>
                  <p className="text-gray-600">{module.description}</p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Gallery Section */}
      <section id="gallery" className="px-4 py-12 bg-gray-50">
        <div className="mx-auto max-w-4xl">
          <h2 className="text-2xl font-bold text-center text-primary mb-6">
            Project Gallery
          </h2>

          {/* Upload Section */}
          <label className="block mb-6">
            <div className="flex items-center justify-center w-full px-6 py-8 border-2 border-dashed border-primary rounded-lg cursor-pointer hover:bg-primary/5 transition-colors">
              <div className="text-center">
                <ImageIcon className="h-8 w-8 text-primary mx-auto mb-1" />
                <p className="text-sm font-semibold text-gray-900">Add Images</p>
                <p className="text-xs text-gray-500">Agriculture images & screenshots</p>
              </div>
            </div>
            <input
              type="file"
              multiple
              accept="image/*"
              onChange={handleImageUpload}
              className="hidden"
            />
          </label>

          {/* Image Grid */}
          {uploadedImages.length > 0 && (
            <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
              {uploadedImages.map((image, idx) => (
                <div
                  key={idx}
                  className="relative group overflow-hidden rounded-lg shadow-sm hover:shadow-md transition-shadow"
                >
                  <img
                    src={image}
                    alt={`Gallery ${idx + 1}`}
                    className="w-full h-40 object-cover group-hover:scale-105 transition-transform"
                  />
                  <button
                    onClick={() =>
                      setUploadedImages(uploadedImages.filter((_, i) => i !== idx))
                    }
                    className="absolute top-1 right-1 bg-red-500 text-white p-1 rounded text-xs opacity-0 group-hover:opacity-100 transition-opacity"
                  >
                    ×
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>
      </section>

      {/* File Upload Section */}
      <section id="upload" className="px-4 py-12">
        <div className="mx-auto max-w-4xl">
          <h2 className="text-2xl font-bold text-center text-primary mb-6">
            Upload Media & Documents
          </h2>

          <div className="grid md:grid-cols-3 gap-4">
            {/* Documents Upload */}
            <div className="bg-white rounded-lg border border-gray-200 p-4">
              <div className="text-center mb-4">
                <FileText className="h-8 w-8 text-primary mx-auto mb-2" />
                <p className="font-semibold text-sm text-gray-900">Documents</p>
                <p className="text-xs text-gray-500">PDF, DOCX, PPT</p>
              </div>
              <label className="block">
                <div className="flex items-center justify-center w-full px-4 py-6 border-2 border-dashed border-primary rounded-lg cursor-pointer hover:bg-primary/5 transition-colors">
                  <div className="text-center">
                    <Upload className="h-6 w-6 text-primary mx-auto" />
                  </div>
                </div>
                <input
                  type="file"
                  accept=".pdf,.docx,.ppt,.pptx,.zip"
                  onChange={handleFileUpload}
                  className="hidden"
                />
              </label>
              {uploadedFile && (
                <div className="mt-3 bg-gray-50 rounded p-2 text-xs">
                  <p className="font-semibold text-gray-900 truncate">{uploadedFile.name}</p>
                  <div className="flex justify-between items-center mt-1">
                    <p className="text-gray-500">{(uploadedFile.size / 1024).toFixed(0)} KB</p>
                    <button
                      onClick={() => setUploadedFile(null)}
                      className="text-red-500 hover:text-red-700 font-bold"
                    >
                      ×
                    </button>
                  </div>
                </div>
              )}
            </div>

            {/* Audio Upload */}
            <div className="bg-white rounded-lg border border-gray-200 p-4">
              <div className="text-center mb-4">
                <span className="text-2xl">🎵</span>
                <p className="font-semibold text-sm text-gray-900 mt-1">Audio</p>
                <p className="text-xs text-gray-500">MP3, WAV, M4A</p>
              </div>
              <label className="block">
                <div className="flex items-center justify-center w-full px-4 py-6 border-2 border-dashed border-primary rounded-lg cursor-pointer hover:bg-primary/5 transition-colors">
                  <div className="text-center">
                    <Upload className="h-6 w-6 text-primary mx-auto" />
                  </div>
                </div>
                <input
                  type="file"
                  accept="audio/*"
                  onChange={handleAudioUpload}
                  className="hidden"
                />
              </label>
              {uploadedAudio && (
                <div className="mt-3 bg-gray-50 rounded p-2 text-xs">
                  <p className="font-semibold text-gray-900 truncate">{uploadedAudio.name}</p>
                  <div className="flex justify-between items-center mt-1">
                    <p className="text-gray-500">{(uploadedAudio.size / 1024).toFixed(0)} KB</p>
                    <button
                      onClick={() => setUploadedAudio(null)}
                      className="text-red-500 hover:text-red-700 font-bold"
                    >
                      ×
                    </button>
                  </div>
                </div>
              )}
            </div>

            {/* Video Upload */}
            <div className="bg-white rounded-lg border border-gray-200 p-4">
              <div className="text-center mb-4">
                <span className="text-2xl">🎬</span>
                <p className="font-semibold text-sm text-gray-900 mt-1">Video</p>
                <p className="text-xs text-gray-500">MP4, WebM, MOV</p>
              </div>
              <label className="block">
                <div className="flex items-center justify-center w-full px-4 py-6 border-2 border-dashed border-primary rounded-lg cursor-pointer hover:bg-primary/5 transition-colors">
                  <div className="text-center">
                    <Upload className="h-6 w-6 text-primary mx-auto" />
                  </div>
                </div>
                <input
                  type="file"
                  accept="video/*"
                  onChange={handleVideoUpload}
                  className="hidden"
                />
              </label>
              {uploadedVideo && (
                <div className="mt-3 bg-gray-50 rounded p-2 text-xs">
                  <p className="font-semibold text-gray-900 truncate">{uploadedVideo.name}</p>
                  <div className="flex justify-between items-center mt-1">
                    <p className="text-gray-500">{(uploadedVideo.size / 1024 / 1024).toFixed(1)} MB</p>
                    <button
                      onClick={() => setUploadedVideo(null)}
                      className="text-red-500 hover:text-red-700 font-bold"
                    >
                      ×
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </section>

      {/* Team Section */}
      <section id="team" className="px-4 py-16 sm:py-20 bg-gray-50">
        <div className="mx-auto max-w-6xl">
          <h2 className="text-3xl font-bold text-center text-primary mb-12">
            Project Team
          </h2>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {teamMembers.map((member, idx) => (
              <div
                key={idx}
                className="bg-white rounded-xl overflow-hidden shadow-md hover:shadow-xl transition-shadow border border-gray-200"
              >
                <div className="bg-gradient-to-br from-primary to-secondary h-32"></div>
                <div className="p-6 text-center">
                  <h3 className="text-lg font-bold text-gray-900">{member.name}</h3>
                  <p className="text-sm text-primary font-semibold mt-1">{member.role}</p>
                  <p className="text-xs text-gray-500 mt-2">{member.id}</p>
                  <div className="flex justify-center gap-3 mt-4">
                    <button className="text-gray-400 hover:text-primary transition-colors">
                      <Linkedin className="h-5 w-5" />
                    </button>
                    <button className="text-gray-400 hover:text-primary transition-colors">
                      <Github className="h-5 w-5" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Technology Stack Section */}
      <section className="px-4 py-16 sm:py-20">
        <div className="mx-auto max-w-6xl">
          <h2 className="text-3xl font-bold text-center text-primary mb-12">
            Technology Stack
          </h2>

          <div className="space-y-12">
            {["Frontend", "Backend", "Database", "AI/ML", "Integration"].map((category) => (
              <div key={category}>
                <h3 className="text-xl font-bold text-gray-900 mb-6 flex items-center gap-2">
                  <div className="w-1 h-6 bg-primary rounded"></div>
                  {category}
                </h3>
                <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-6">
                  {technologies
                    .filter((tech) => {
                      if (category === "Frontend")
                        return ["HTML", "CSS", "JavaScript"].includes(tech.name);
                      if (category === "Backend")
                        return ["Python", "C#", "ASP.NET", "Flask"].includes(
                          tech.name
                        );
                      if (category === "Database") return tech.name === "MySQL";
                      if (category === "AI/ML")
                        return tech.name === "Machine Learning";
                      if (category === "Integration")
                        return ["Weather API", "APMC Market API"].includes(tech.name);
                      return false;
                    })
                    .map((tech) => (
                      <div
                        key={tech.name}
                        className="flex flex-col items-center gap-4 p-6 rounded-lg bg-gray-50 border border-gray-200 hover:border-primary hover:bg-white transition-all"
                      >
                        <TechIcon name={tech.name} />
                        <p className="text-sm font-semibold text-gray-900 text-center">
                          {tech.name}
                        </p>
                      </div>
                    ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="px-4 py-16 sm:py-20 bg-gradient-to-br from-primary to-secondary">
        <div className="mx-auto max-w-4xl">
          <h2 className="text-3xl font-bold text-center text-white mb-12">
            Get In Touch
          </h2>

          <div className="grid md:grid-cols-3 gap-8">
            <div className="text-center text-white">
              <div className="inline-block rounded-lg bg-white/20 p-4 mb-4">
                <Mail className="h-8 w-8" />
              </div>
              <h3 className="font-bold mb-2">Email</h3>
              <p className="text-white/80">dass.project@university.ac.in</p>
            </div>
            <div className="text-center text-white">
              <div className="inline-block rounded-lg bg-white/20 p-4 mb-4">
                <Phone className="h-8 w-8" />
              </div>
              <h3 className="font-bold mb-2">Phone</h3>
              <p className="text-white/80">+91 (XXX) XXX-XXXX</p>
            </div>
            <div className="text-center text-white">
              <div className="inline-block rounded-lg bg-white/20 p-4 mb-4">
                <MapPin className="h-8 w-8" />
              </div>
              <h3 className="font-bold mb-2">Location</h3>
              <p className="text-white/80">University Campus, India</p>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white px-4 py-12">
        <div className="mx-auto max-w-6xl">
          <div className="grid md:grid-cols-3 gap-8 mb-8">
            <div>
              <h4 className="font-bold mb-4">Digital Agriculture Support System</h4>
              <p className="text-gray-400">Empowering farmers with digital innovation</p>
            </div>
            <div>
              <h4 className="font-bold mb-4">Quick Links</h4>
              <ul className="space-y-2 text-gray-400">
                <li>
                  <a href="#abstract" className="hover:text-white transition-colors">
                    Abstract
                  </a>
                </li>
                <li>
                  <a href="#modules" className="hover:text-white transition-colors">
                    Modules
                  </a>
                </li>
                <li>
                  <a href="#team" className="hover:text-white transition-colors">
                    Team
                  </a>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold mb-4">Follow Us</h4>
              <div className="flex gap-4">
                <a href="#" className="text-gray-400 hover:text-white transition-colors">
                  <Github className="h-5 w-5" />
                </a>
                <a href="#" className="text-gray-400 hover:text-white transition-colors">
                  <Linkedin className="h-5 w-5" />
                </a>
              </div>
            </div>
          </div>
          <div className="border-t border-gray-800 pt-8 text-center text-gray-400">
            <p>
              © 2024 Digital Agriculture Support System. All rights reserved.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
